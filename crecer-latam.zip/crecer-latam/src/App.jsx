import { useState, useEffect } from "react";
import {
  MapPin, Filter, X, Check, Copy, ExternalLink, Sparkles,
  ArrowRight, Instagram, Youtube, Mail, ChevronDown, Menu,
  Music2, BadgeCheck, MessageCircle, Users, ArrowLeft, KeyRound
} from "lucide-react";
import { supabase } from "./supabaseClient";

const PAISES = ["México", "Argentina", "Panamá", "Colombia", "Chile", "Perú", "España", "Estados Unidos", "Otro"];
const CATEGORIAS = ["Moda", "Belleza", "Maternidad", "Comida", "Tecnología", "Fitness", "Hogar", "Mascotas", "Viajes", "Lifestyle"];
const PLATAFORMAS = ["Instagram", "TikTok", "YouTube"];

const PLATFORM_ICON = { Instagram, TikTok: Music2, YouTube: Youtube };

function uid() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}
function genCode() {
  return Math.random().toString(36).slice(2, 8).toUpperCase();
}

function Avatar({ creator, size = 56 }) {
  const initials = creator.nombre
    ? creator.nombre.trim().split(/\s+/).slice(0, 2).map(w => w[0]).join("").toUpperCase()
    : "?";
  if (creator.fotoUrl) {
    return (
      <img
        src={creator.fotoUrl}
        alt={creator.nombre}
        style={{ width: size, height: size }}
        className="rounded-full object-cover border-2 flex-shrink-0"
        onError={(e) => { e.target.style.display = "none"; }}
      />
    );
  }
  return (
    <div
      style={{ width: size, height: size, background: "#1F5C4E" }}
      className="rounded-full flex items-center justify-center flex-shrink-0"
    >
      <span className="font-display text-paper" style={{ fontSize: size * 0.36 }}>{initials}</span>
    </div>
  );
}

function Chip({ active, onClick, children }) {
  return (
    <button
      onClick={onClick}
      type="button"
      className={`px-3 py-1.5 rounded-full text-sm border transition-colors ${
        active ? "bg-ink text-paper border-ink" : "bg-transparent text-ink border-line hover:border-ink"
      }`}
    >
      {children}
    </button>
  );
}

function Field({ label, required, children, hint }) {
  return (
    <label className="block mb-5">
      <span className="block text-xs font-mono uppercase tracking-wider text-ink/60 mb-1.5">
        {label}{required && <span className="text-coral"> *</span>}
      </span>
      {children}
      {hint && <span className="block text-xs text-ink/45 mt-1">{hint}</span>}
    </label>
  );
}

const inputCls = "w-full border border-line rounded-lg px-3.5 py-2.5 text-ink bg-paper focus:outline-none focus:ring-2 focus:ring-coral/40 focus:border-coral placeholder:text-ink/35";

export default function App() {
  const [view, setView] = useState("home");
  const [creators, setCreators] = useState([]);
  const [loading, setLoading] = useState(true);
  const [storageError, setStorageError] = useState(false);
  const [lastCode, setLastCode] = useState(null);
  const [dashCreator, setDashCreator] = useState(null);
  const [navOpen, setNavOpen] = useState(false);

  useEffect(() => { loadCreators(); }, []);

  // Convierte una fila de Supabase (snake_case) al formato que usa la interfaz (camelCase)
  function fromDb(row) {
    return {
      id: row.id,
      nombre: row.nombre,
      pais: row.pais,
      ciudad: row.ciudad,
      edad: row.edad,
      tarifaDesde: row.tarifa_desde,
      categorias: row.categorias || [],
      plataformas: row.plataformas || [],
      portafolioUrl: row.portafolio_url,
      contacto: row.contacto,
      fotoUrl: row.foto_url,
      bio: row.bio,
      accessCode: row.access_code,
      contactCount: row.contact_count || 0,
      createdAt: row.created_at,
    };
  }

  // Convierte el formato de la interfaz (camelCase) a columnas de Supabase (snake_case)
  function toDb(c) {
    return {
      nombre: c.nombre,
      pais: c.pais,
      ciudad: c.ciudad,
      edad: Number(c.edad),
      tarifa_desde: Number(c.tarifaDesde),
      categorias: c.categorias,
      plataformas: c.plataformas,
      portafolio_url: c.portafolioUrl,
      contacto: c.contacto,
      foto_url: c.fotoUrl || null,
      bio: c.bio || null,
    };
  }

  async function loadCreators() {
    setLoading(true);
    const { data, error } = await supabase
      .from("creators")
      .select("*")
      .order("created_at", { ascending: false });
    if (error) { setStorageError(true); setCreators([]); }
    else setCreators((data || []).map(fromDb));
    setLoading(false);
  }

  async function addCreator(data) {
    const code = genCode();
    const { data: inserted, error } = await supabase
      .from("creators")
      .insert([{ ...toDb(data), access_code: code }])
      .select()
      .single();
    if (error) { setStorageError(true); return; }
    setCreators([fromDb(inserted), ...creators]);
    setLastCode(code);
    setView("creatorSuccess");
  }

  async function registerContact(id) {
    const target = creators.find(c => c.id === id);
    if (!target) return;
    const nextCount = (target.contactCount || 0) + 1;
    const { error } = await supabase
      .from("creators")
      .update({ contact_count: nextCount })
      .eq("id", id);
    if (error) { setStorageError(true); return; }
    setCreators(creators.map(c => c.id === id ? { ...c, contactCount: nextCount } : c));
  }

  async function updateCreator(updated) {
    const { error } = await supabase
      .from("creators")
      .update(toDb(updated))
      .eq("id", updated.id);
    if (error) { setStorageError(true); return; }
    setCreators(creators.map(c => c.id === updated.id ? updated : c));
    setDashCreator(updated);
  }

  function goTo(v) { setView(v); setNavOpen(false); window.scrollTo(0, 0); }

  return (
    <div className="min-h-screen bg-paper text-ink" style={{ fontFamily: "Inter, sans-serif" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Anton&family=Inter:wght@400;500;600;700&family=IBM+Plex+Mono:wght@400;500&display=swap');
        .bg-paper { background-color: #F3EEE3; }
        .text-ink { color: #1A1A1A; }
        .text-paper { color: #F3EEE3; }
        .bg-ink { background-color: #1A1A1A; }
        .bg-coral { background-color: #FF4D5E; }
        .text-coral { color: #FF4D5E; }
        .border-coral { border-color: #FF4D5E; }
        .bg-teal { background-color: #6D28D9; }
        .text-teal { color: #6D28D9; }
        .border-teal { border-color: #6D28D9; }
        .bg-lime { background-color: #D7FF3F; }
        .text-lime { color: #D7FF3F; }
        .border-line { border-color: rgba(26,26,26,0.14); }
        .font-display { font-family: 'Anton', sans-serif; letter-spacing: 0.01em; }
        .font-mono { font-family: 'IBM Plex Mono', monospace; }
        .hero-gradient { background: linear-gradient(150deg, #7C3AED 0%, #5B21B6 55%, #2E1065 100%); }
        .filmstrip { position: relative; }
        .filmstrip::before {
          content: "";
          position: absolute; top: 0; left: 0; right: 0; height: 10px;
          background-image: radial-gradient(circle, #F3EEE3 3px, transparent 3.5px);
          background-size: 16px 10px; background-position: 4px 0;
          background-color: #1A1A1A; border-radius: 10px 10px 0 0;
        }
      `}</style>

      {/* NAV */}
      <header className="sticky top-0 z-40 bg-paper/95 backdrop-blur border-b border-line">
        <div className="max-w-6xl mx-auto px-5 sm:px-8 h-16 flex items-center justify-between">
          <button onClick={() => goTo("home")} className="font-display text-2xl tracking-tight inline-flex items-center gap-2">
            CRECER<span className="text-coral">.</span>
            <span className="hidden sm:inline-block text-[10px] font-mono uppercase bg-lime text-ink px-2 py-0.5 rounded-full tracking-wider">LATAM</span>
          </button>
          <nav className="hidden md:flex items-center gap-1">
            <NavBtn active={view === "directory"} onClick={() => goTo("directory")}>Directorio</NavBtn>
            <NavBtn active={view === "creatorForm"} onClick={() => goTo("creatorForm")}>Soy creador/a</NavBtn>
            <NavBtn active={view === "creatorLogin"} onClick={() => goTo("creatorLogin")}>Mis estadísticas</NavBtn>
            <button onClick={() => goTo("directory")} className="ml-2 bg-coral text-paper px-4 py-2 rounded-full text-sm font-semibold hover:opacity-90">
              Soy marca
            </button>
          </nav>
          <button className="md:hidden" onClick={() => setNavOpen(!navOpen)}><Menu size={22} /></button>
        </div>
        {navOpen && (
          <div className="md:hidden border-t border-line px-5 py-3 flex flex-col gap-2">
            <NavBtn active={view === "directory"} onClick={() => goTo("directory")}>Directorio</NavBtn>
            <NavBtn active={view === "creatorForm"} onClick={() => goTo("creatorForm")}>Soy creador/a</NavBtn>
            <NavBtn active={view === "creatorLogin"} onClick={() => goTo("creatorLogin")}>Mis estadísticas</NavBtn>
          </div>
        )}
      </header>

      {view === "home" && <Home goTo={goTo} count={creators.length} />}
      {view === "directory" && (
        <Directory creators={creators} loading={loading} onContact={registerContact} goTo={goTo} />
      )}
      {view === "creatorForm" && <CreatorForm onSubmit={addCreator} goTo={goTo} />}
      {view === "creatorSuccess" && <CreatorSuccess code={lastCode} goTo={goTo} />}
      {view === "creatorLogin" && (
        <CreatorLogin
          creators={creators}
          onFound={(c) => { setDashCreator(c); goTo("creatorDashboard"); }}
        />
      )}
      {view === "creatorDashboard" && dashCreator && (
        <CreatorDashboard creator={dashCreator} onUpdate={updateCreator} goTo={goTo} />
      )}

      {storageError && (
        <div className="fixed bottom-4 left-1/2 -translate-x-1/2 bg-ink text-paper text-sm px-4 py-2 rounded-full">
          Hubo un problema guardando los datos. Intenta de nuevo.
        </div>
      )}

      <footer className="border-t border-line mt-24 py-10 px-5 sm:px-8">
        <div className="max-w-6xl mx-auto flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 text-sm text-ink/55">
          <span className="font-display text-lg text-ink">CRECER<span className="text-coral">.</span></span>
          <span>El directorio de creadoras y creadores UGC hecho para filtrar, no para saturar.</span>
        </div>
      </footer>
    </div>
  );
}

function NavBtn({ active, onClick, children }) {
  return (
    <button
      onClick={onClick}
      className={`px-3 py-2 rounded-full text-sm font-medium ${active ? "bg-ink text-paper" : "hover:bg-ink/5"}`}
    >
      {children}
    </button>
  );
}

/* ---------------- HOME ---------------- */
const BENEF_MARCA = [
  "Filtras por ubicación, edad y tarifa exacta",
  "Cero spam en tu correo o tu Instagram",
  "Ves el portafolio antes de escribir",
];
const BENEF_CREADORA = [
  "Te encuentran marcas afines a tu nicho",
  "Tú pones tu tarifa, nadie regatea",
  "Mides cuántas marcas te contactan",
];

function ChecklistCard({ eyebrow, title, items, tone }) {
  return (
    <div className={`rounded-2xl p-6 flex-1 ${tone === "lime" ? "bg-lime text-ink" : "bg-paper/10 border border-paper/20 text-paper"}`}>
      <span className={`font-mono text-xs uppercase tracking-widest ${tone === "lime" ? "text-ink/60" : "text-paper/60"}`}>{eyebrow}</span>
      <h3 className="font-display text-2xl mt-1 mb-4">{title}</h3>
      <ul className="space-y-2.5">
        {items.map(item => (
          <li key={item} className="flex items-start gap-2 text-sm leading-snug">
            <Check size={16} className={`mt-0.5 flex-shrink-0 ${tone === "lime" ? "text-ink" : "text-lime"}`} />
            {item}
          </li>
        ))}
      </ul>
    </div>
  );
}

function Home({ goTo, count }) {
  return (
    <main>
      <section className="hero-gradient text-paper">
        <div className="max-w-3xl mx-auto px-5 sm:px-8 pt-14 sm:pt-20 pb-16 text-center">
          <span className="inline-flex items-center gap-1.5 bg-lime text-ink text-xs font-mono uppercase tracking-wider px-3 py-1 rounded-full">
            🌎 100% Latinoamérica
          </span>
          <h1 className="font-display text-4xl sm:text-5xl md:text-6xl leading-[1.08] tracking-tight mt-5">
            EL DIRECTORIO UGC DE LATINOAMÉRICA
          </h1>
          <p className="text-base sm:text-lg text-paper/85 mt-4 leading-relaxed max-w-xl mx-auto">
            Filtra o publica tu ficha. Sin convocatorias masivas, sin spam.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 mt-10 text-left">
            <ChecklistCard eyebrow="Para marcas" title="Buscas creadoras" items={BENEF_MARCA} tone="dark" />
            <ChecklistCard eyebrow="Para creadoras y creadores" title="Creas contenido" items={BENEF_CREADORA} tone="lime" />
          </div>

          <div className="flex flex-col sm:flex-row gap-4 mt-8">
            <button
              onClick={() => goTo("directory")}
              className="group bg-lime text-ink px-7 py-4 rounded-2xl flex-1 flex items-center justify-center gap-2 font-display text-xl"
            >
              SOY MARCA <ArrowRight size={17} className="group-hover:translate-x-1 transition-transform" />
            </button>
            <button
              onClick={() => goTo("creatorForm")}
              className="group bg-coral text-paper px-7 py-4 rounded-2xl flex-1 flex items-center justify-center gap-2 font-display text-xl"
            >
              SOY CREADOR/A UGC <ArrowRight size={17} className="group-hover:translate-x-1 transition-transform" />
            </button>
          </div>

          <p className="font-mono text-xs text-paper/60 mt-6">
            {count > 0
              ? `🚀 Programa fundador: ${count} fichas activas y sumando.`
              : "🚀 Programa fundador: sé de las primeras fichas en aparecer en el directorio."}
          </p>
        </div>
      </section>

      <section className="border-t border-line py-16 px-5 sm:px-8">
        <div className="max-w-6xl mx-auto grid md:grid-cols-2 gap-12">
          <div>
            <span className="font-mono text-xs uppercase tracking-widest text-coral">Para marcas</span>
            <h2 className="font-display text-3xl mt-2 mb-6">CÓMO FUNCIONA</h2>
            <Step n="01" title="Filtra">Elige ubicación, rango de edad y tarifa, categoría y plataforma. Solo ves lo que aplica a ti.</Step>
            <Step n="02" title="Revisa el portafolio">Cada ficha incluye el link real del portafolio — lo abres tú, cuando quieras.</Step>
            <Step n="03" title="Contacta directo">Sin intermediarios ni convocatorias. Tú decides a quién escribir.</Step>
          </div>
          <div>
            <span className="font-mono text-xs uppercase tracking-widest text-teal">Para creadoras y creadores</span>
            <h2 className="font-display text-3xl mt-2 mb-6">CÓMO FUNCIONA</h2>
            <Step n="01" title="Crea tu ficha">Nombre, ubicación, edad, tarifa, categorías y tu portafolio. Toma 3 minutos.</Step>
            <Step n="02" title="Quedas visible">Las marcas te encuentran filtrando — no hace falta que apliques a nada.</Step>
            <Step n="03" title="Mide tus contactos">Con tu código de acceso ves cuántas marcas te han contactado.</Step>
          </div>
        </div>
      </section>

      <section className="border-t border-line py-16 px-5 sm:px-8 bg-teal text-paper">
        <div className="max-w-5xl mx-auto">
          <span className="font-mono text-xs uppercase tracking-widest text-lime">Por qué CRECER</span>
          <h2 className="font-display text-3xl sm:text-4xl mt-2 mb-8 max-w-lg">MENOS RUIDO, MÁS RESULTADOS.</h2>
          <div className="grid sm:grid-cols-3 gap-6">
            <div>
              <p className="font-display text-2xl text-lime mb-1">01</p>
              <p className="font-semibold mb-1">Sin convocatorias masivas</p>
              <p className="text-sm text-paper/75">Nadie manda mensajes en cadena. Tú buscas o te encuentran, punto.</p>
            </div>
            <div>
              <p className="font-display text-2xl text-lime mb-1">02</p>
              <p className="font-semibold mb-1">Datos reales, no infladas</p>
              <p className="text-sm text-paper/75">Cada ficha y cada contacto registrado es real — nada de cifras inventadas.</p>
            </div>
            <div>
              <p className="font-display text-2xl text-lime mb-1">03</p>
              <p className="font-semibold mb-1">Hecho para Latinoamérica</p>
              <p className="text-sm text-paper/75">Pensado desde y para el mercado UGC de la región, no una traducción de otro país.</p>
            </div>
          </div>
        </div>
      </section>

      <section className="border-t border-line py-16 px-5 sm:px-8 bg-ink text-paper">
        <div className="max-w-6xl mx-auto text-center">
          <h2 className="font-display text-3xl sm:text-4xl max-w-2xl mx-auto">
            ¿LISTO/A PARA QUE TE ENCUENTREN LAS MARCAS QUE SÍ TE CONVIENEN?
          </h2>
          <button onClick={() => goTo("creatorForm")} className="bg-lime text-ink px-7 py-3.5 rounded-full font-semibold mt-8 inline-flex items-center gap-2">
            Crear mi perfil <ArrowRight size={16} />
          </button>
        </div>
      </section>
    </main>
  );
}

function Step({ n, title, children }) {
  return (
    <div className="flex gap-4 mb-6">
      <span className="font-mono text-sm text-ink/35 pt-0.5">{n}</span>
      <div>
        <h3 className="font-semibold mb-1">{title}</h3>
        <p className="text-sm text-ink/65 leading-relaxed">{children}</p>
      </div>
    </div>
  );
}

/* ---------------- DIRECTORY (MARCAS) ---------------- */
function Directory({ creators, loading, onContact, goTo }) {
  const [filtersOpen, setFiltersOpen] = useState(false);
  const [pais, setPais] = useState("");
  const [cats, setCats] = useState([]);
  const [plats, setPlats] = useState([]);
  const [edadMin, setEdadMin] = useState("");
  const [edadMax, setEdadMax] = useState("");
  const [tarifaMin, setTarifaMin] = useState("");
  const [tarifaMax, setTarifaMax] = useState("");

  const toggle = (arr, set, v) => set(arr.includes(v) ? arr.filter(x => x !== v) : [...arr, v]);

  const filtered = creators.filter(c => {
    if (pais && c.pais !== pais) return false;
    if (cats.length && !cats.some(cat => c.categorias.includes(cat))) return false;
    if (plats.length && !plats.some(p => c.plataformas.includes(p))) return false;
    if (edadMin && Number(c.edad) < Number(edadMin)) return false;
    if (edadMax && Number(c.edad) > Number(edadMax)) return false;
    if (tarifaMin && Number(c.tarifaDesde) < Number(tarifaMin)) return false;
    if (tarifaMax && Number(c.tarifaDesde) > Number(tarifaMax)) return false;
    return true;
  });

  const clearAll = () => { setPais(""); setCats([]); setPlats([]); setEdadMin(""); setEdadMax(""); setTarifaMin(""); setTarifaMax(""); };
  const activeCount = [pais, edadMin, edadMax, tarifaMin, tarifaMax].filter(Boolean).length + cats.length + plats.length;

  return (
    <main className="max-w-6xl mx-auto px-5 sm:px-8 py-10">
      <div className="flex items-end justify-between flex-wrap gap-3 mb-6">
        <div>
          <span className="font-mono text-xs uppercase tracking-widest text-coral">Directorio · LATAM</span>
          <h1 className="font-display text-4xl mt-1">CREADORAS Y CREADORES UGC</h1>
        </div>
        <button
          onClick={() => setFiltersOpen(!filtersOpen)}
          className="md:hidden inline-flex items-center gap-1.5 border border-line rounded-full px-4 py-2 text-sm"
        >
          <Filter size={14} /> Filtros {activeCount > 0 && `(${activeCount})`}
        </button>
      </div>

      <div className="grid md:grid-cols-[240px_1fr] gap-8">
        <aside className={`${filtersOpen ? "block" : "hidden"} md:block`}>
          <div className="border border-line rounded-2xl p-5 sticky top-24">
            <div className="flex items-center justify-between mb-4">
              <span className="font-mono text-xs uppercase tracking-widest">Filtros</span>
              {activeCount > 0 && <button onClick={clearAll} className="text-xs text-coral">Limpiar</button>}
            </div>

            <FilterLabel>País</FilterLabel>
            <select value={pais} onChange={e => setPais(e.target.value)} className={inputCls + " mb-5 text-sm"}>
              <option value="">Todos</option>
              {PAISES.map(p => <option key={p} value={p}>{p}</option>)}
            </select>

            <FilterLabel>Edad</FilterLabel>
            <div className="flex gap-2 mb-5">
              <input type="number" placeholder="Mín" value={edadMin} onChange={e => setEdadMin(e.target.value)} className={inputCls + " text-sm"} />
              <input type="number" placeholder="Máx" value={edadMax} onChange={e => setEdadMax(e.target.value)} className={inputCls + " text-sm"} />
            </div>

            <FilterLabel>Tarifa desde (USD)</FilterLabel>
            <div className="flex gap-2 mb-5">
              <input type="number" placeholder="Mín" value={tarifaMin} onChange={e => setTarifaMin(e.target.value)} className={inputCls + " text-sm"} />
              <input type="number" placeholder="Máx" value={tarifaMax} onChange={e => setTarifaMax(e.target.value)} className={inputCls + " text-sm"} />
            </div>

            <FilterLabel>Categoría</FilterLabel>
            <div className="flex flex-wrap gap-1.5 mb-5">
              {CATEGORIAS.map(c => (
                <Chip key={c} active={cats.includes(c)} onClick={() => toggle(cats, setCats, c)}>{c}</Chip>
              ))}
            </div>

            <FilterLabel>Plataforma</FilterLabel>
            <div className="flex flex-wrap gap-1.5">
              {PLATAFORMAS.map(p => (
                <Chip key={p} active={plats.includes(p)} onClick={() => toggle(plats, setPlats, p)}>{p}</Chip>
              ))}
            </div>
          </div>
        </aside>

        <div>
          {loading ? (
            <p className="text-ink/50 font-mono text-sm">Cargando…</p>
          ) : creators.length === 0 ? (
            <EmptyDirectory goTo={goTo} />
          ) : filtered.length === 0 ? (
            <div className="border border-dashed border-line rounded-2xl p-10 text-center">
              <p className="font-display text-2xl mb-2">SIN RESULTADOS</p>
              <p className="text-ink/60 text-sm">Ninguna ficha coincide con esos filtros todavía. Prueba ajustarlos.</p>
            </div>
          ) : (
            <>
              <p className="font-mono text-xs text-ink/50 mb-4">{filtered.length} creadora{filtered.length !== 1 && "s"} encontrada{filtered.length !== 1 && "s"}</p>
              <div className="grid sm:grid-cols-2 gap-5">
                {filtered.map(c => <CreatorCard key={c.id} creator={c} onContact={onContact} />)}
              </div>
            </>
          )}
        </div>
      </div>
    </main>
  );
}

function FilterLabel({ children }) {
  return <span className="block font-mono text-[11px] uppercase tracking-wider text-ink/50 mb-2">{children}</span>;
}

function EmptyDirectory({ goTo }) {
  return (
    <div className="border border-dashed border-line rounded-2xl p-12 text-center">
      <BadgeCheck className="mx-auto mb-3 text-teal" size={30} />
      <p className="font-display text-3xl mb-2">MUY PRONTO</p>
      <p className="text-ink/65 max-w-sm mx-auto mb-6">
        Estamos abriendo el directorio. Todavía no hay creadoras ni creadores registrados públicamente — vuelve pronto o avísale a alguien que conozcas que cree contenido UGC.
      </p>
      <button onClick={() => goTo("creatorForm")} className="bg-ink text-paper px-5 py-2.5 rounded-full text-sm font-semibold">
        Invitar / crear un perfil
      </button>
    </div>
  );
}

function CreatorCard({ creator, onContact }) {
  const [revealed, setRevealed] = useState(false);

  const handleContact = () => {
    if (!revealed) { onContact(creator.id); setRevealed(true); }
  };

  return (
    <div className="filmstrip border border-line rounded-2xl overflow-hidden pt-3 bg-white/40">
      <div className="p-5">
        <div className="flex items-start gap-3">
          <Avatar creator={creator} />
          <div className="min-w-0">
            <p className="font-semibold leading-tight truncate">{creator.nombre}</p>
            <p className="text-xs text-ink/55 inline-flex items-center gap-1 mt-0.5">
              <MapPin size={11} /> {creator.ciudad}, {creator.pais} · {creator.edad} años
            </p>
          </div>
          <span className="ml-auto font-mono text-xs bg-teal text-paper px-2 py-1 rounded-full whitespace-nowrap">
            desde ${creator.tarifaDesde}
          </span>
        </div>

        {creator.bio && <p className="text-sm text-ink/70 mt-3 leading-snug">{creator.bio}</p>}

        <div className="flex flex-wrap gap-1.5 mt-3">
          {creator.categorias.map(c => (
            <span key={c} className="text-[11px] font-mono border border-line rounded-full px-2 py-0.5">{c}</span>
          ))}
        </div>

        <div className="flex items-center gap-2 mt-3">
          {creator.plataformas.map(p => {
            const Icon = PLATFORM_ICON[p] || Sparkles;
            return <Icon key={p} size={15} className="text-ink/55" />;
          })}
        </div>

        <div className="flex items-center gap-2 mt-4">
          <a
            href={creator.portafolioUrl}
            target="_blank" rel="noopener noreferrer"
            className="flex-1 text-center text-sm border border-line rounded-full py-2 inline-flex items-center justify-center gap-1.5 hover:border-ink"
          >
            Ver portafolio <ExternalLink size={13} />
          </a>
          <button
            onClick={handleContact}
            className={`flex-1 text-sm rounded-full py-2 font-semibold inline-flex items-center justify-center gap-1.5 ${revealed ? "bg-teal text-paper" : "bg-coral text-paper hover:opacity-90"}`}
          >
            {revealed ? <Check size={14} /> : <MessageCircle size={14} />} {revealed ? "Contacto abajo" : "Contactar"}
          </button>
        </div>

        {revealed && (
          <div className="mt-3 bg-ink/5 rounded-lg px-3 py-2 text-sm font-mono break-all">
            {creator.contacto}
          </div>
        )}
      </div>
    </div>
  );
}

/* ---------------- CREATOR FORM ---------------- */
function CreatorForm({ onSubmit, goTo }) {
  const [nombre, setNombre] = useState("");
  const [pais, setPais] = useState("");
  const [ciudad, setCiudad] = useState("");
  const [edad, setEdad] = useState("");
  const [tarifaDesde, setTarifaDesde] = useState("");
  const [categorias, setCategorias] = useState([]);
  const [plataformas, setPlataformas] = useState([]);
  const [portafolioUrl, setPortafolioUrl] = useState("");
  const [contacto, setContacto] = useState("");
  const [fotoUrl, setFotoUrl] = useState("");
  const [bio, setBio] = useState("");
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const toggle = (arr, set, v) => set(arr.includes(v) ? arr.filter(x => x !== v) : [...arr, v]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!nombre || !pais || !ciudad || !edad || !tarifaDesde || !portafolioUrl || !contacto || categorias.length === 0 || plataformas.length === 0) {
      setError("Completa todos los campos obligatorios (*) antes de continuar.");
      return;
    }
    if (Number(edad) < 16) { setError("La edad mínima para registrarse es 16 años."); return; }
    setError("");
    setSubmitting(true);
    await onSubmit({ nombre, pais, ciudad, edad, tarifaDesde, categorias, plataformas, portafolioUrl, contacto, fotoUrl, bio });
    setSubmitting(false);
  };

  return (
    <main className="max-w-2xl mx-auto px-5 sm:px-8 py-12">
      <button onClick={() => goTo("home")} className="text-sm text-ink/55 inline-flex items-center gap-1 mb-6"><ArrowLeft size={14} /> Volver</button>
      <span className="font-mono text-xs uppercase tracking-widest text-teal">Perfil de creador/a</span>
      <h1 className="font-display text-4xl mt-1 mb-2">ARMA TU FICHA</h1>
      <p className="text-ink/65 mb-8">Estos datos son los que las marcas van a filtrar. Sé precisa, así te contactan quienes de verdad te convienen.</p>

      <form onSubmit={handleSubmit}>
        <Field label="Nombre o nombre de creador/a" required>
          <input className={inputCls} value={nombre} onChange={e => setNombre(e.target.value)} placeholder="Ej. Camila Ruiz" />
        </Field>

        <div className="grid grid-cols-2 gap-4">
          <Field label="País" required>
            <select className={inputCls} value={pais} onChange={e => setPais(e.target.value)}>
              <option value="">Selecciona</option>
              {PAISES.map(p => <option key={p} value={p}>{p}</option>)}
            </select>
          </Field>
          <Field label="Ciudad" required>
            <input className={inputCls} value={ciudad} onChange={e => setCiudad(e.target.value)} placeholder="Ej. Ciudad de México" />
          </Field>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <Field label="Edad" required>
            <input type="number" min="16" className={inputCls} value={edad} onChange={e => setEdad(e.target.value)} placeholder="Ej. 24" />
          </Field>
          <Field label="Tarifa desde (USD)" required hint="Por publicación/video">
            <input type="number" min="0" className={inputCls} value={tarifaDesde} onChange={e => setTarifaDesde(e.target.value)} placeholder="Ej. 50" />
          </Field>
        </div>

        <Field label="Categorías / nicho" required hint="Elige todas las que apliquen">
          <div className="flex flex-wrap gap-1.5">
            {CATEGORIAS.map(c => <Chip key={c} active={categorias.includes(c)} onClick={() => toggle(categorias, setCategorias, c)}>{c}</Chip>)}
          </div>
        </Field>

        <Field label="Plataformas" required>
          <div className="flex flex-wrap gap-1.5">
            {PLATAFORMAS.map(p => <Chip key={p} active={plataformas.includes(p)} onClick={() => toggle(plataformas, setPlataformas, p)}>{p}</Chip>)}
          </div>
        </Field>

        <Field label="Link de tu portafolio" required hint="Google Drive, carpeta, web, Linktree, etc. — la marca lo abrirá directamente">
          <input className={inputCls} value={portafolioUrl} onChange={e => setPortafolioUrl(e.target.value)} placeholder="https://..." />
        </Field>

        <Field label="Cómo te contactan las marcas" required hint="Email, Instagram o WhatsApp">
          <input className={inputCls} value={contacto} onChange={e => setContacto(e.target.value)} placeholder="Ej. camila@email.com o @camila.ugc" />
        </Field>

        <Field label="Foto de perfil (link a imagen)" hint="Opcional — si lo dejas vacío usamos tus iniciales">
          <input className={inputCls} value={fotoUrl} onChange={e => setFotoUrl(e.target.value)} placeholder="https://..." />
        </Field>

        <Field label="Bio corta" hint="Opcional, máx. 150 caracteres">
          <textarea maxLength={150} rows={3} className={inputCls} value={bio} onChange={e => setBio(e.target.value)} placeholder="Cuéntale a las marcas qué te hace diferente" />
        </Field>

        {error && <p className="text-coral text-sm mb-4">{error}</p>}

        <button disabled={submitting} type="submit" className="w-full bg-coral text-paper py-3.5 rounded-full font-semibold disabled:opacity-60">
          {submitting ? "Guardando…" : "Publicar mi ficha"}
        </button>
      </form>
    </main>
  );
}

function CreatorSuccess({ code, goTo }) {
  const [copied, setCopied] = useState(false);
  const copy = () => {
    navigator.clipboard?.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };
  return (
    <main className="max-w-lg mx-auto px-5 sm:px-8 py-16 text-center">
      <BadgeCheck className="mx-auto text-teal mb-4" size={40} />
      <h1 className="font-display text-4xl mb-3">¡FICHA PUBLICADA!</h1>
      <p className="text-ink/65 mb-8">Ya apareces en el directorio. Guarda este código — es la única forma de ver cuántas marcas te han contactado.</p>
      <div className="border-2 border-dashed border-ink rounded-2xl p-6 mb-6">
        <span className="font-mono text-3xl tracking-widest">{code}</span>
      </div>
      <button onClick={copy} className="inline-flex items-center gap-1.5 text-sm border border-line rounded-full px-4 py-2 mb-8 hover:border-ink">
        <Copy size={14} /> {copied ? "¡Copiado!" : "Copiar código"}
      </button>
      <div className="flex flex-col sm:flex-row gap-3 justify-center">
        <button onClick={() => goTo("directory")} className="bg-ink text-paper px-6 py-3 rounded-full font-semibold">Ver el directorio</button>
        <button onClick={() => goTo("home")} className="border border-line px-6 py-3 rounded-full font-semibold">Ir al inicio</button>
      </div>
    </main>
  );
}

/* ---------------- CREATOR LOGIN / DASHBOARD ---------------- */
function CreatorLogin({ creators, onFound }) {
  const [code, setCode] = useState("");
  const [error, setError] = useState("");
  const submit = (e) => {
    e.preventDefault();
    const found = creators.find(c => c.accessCode === code.trim().toUpperCase());
    if (found) { setError(""); onFound(found); }
    else setError("No encontramos ese código. Revisa que esté bien escrito.");
  };
  return (
    <main className="max-w-md mx-auto px-5 sm:px-8 py-16 text-center">
      <KeyRound className="mx-auto text-teal mb-4" size={32} />
      <h1 className="font-display text-4xl mb-2">MIS ESTADÍSTICAS</h1>
      <p className="text-ink/65 mb-8">Ingresa el código de acceso que recibiste al crear tu ficha.</p>
      <form onSubmit={submit} className="flex flex-col gap-3">
        <input
          className={inputCls + " text-center font-mono tracking-widest text-lg"}
          value={code} onChange={e => setCode(e.target.value)}
          placeholder="XXXXXX" maxLength={12}
        />
        {error && <p className="text-coral text-sm">{error}</p>}
        <button type="submit" className="bg-coral text-paper py-3 rounded-full font-semibold">Entrar</button>
      </form>
    </main>
  );
}

function CreatorDashboard({ creator, onUpdate, goTo }) {
  const [editing, setEditing] = useState(false);
  const [form, setForm] = useState(creator);

  const save = async () => { await onUpdate(form); setEditing(false); };

  return (
    <main className="max-w-2xl mx-auto px-5 sm:px-8 py-12">
      <button onClick={() => goTo("home")} className="text-sm text-ink/55 inline-flex items-center gap-1 mb-6"><ArrowLeft size={14} /> Volver</button>

      <div className="flex items-center gap-4 mb-8">
        <Avatar creator={creator} size={64} />
        <div>
          <h1 className="font-display text-3xl leading-tight">{creator.nombre}</h1>
          <p className="text-ink/55 text-sm">{creator.ciudad}, {creator.pais}</p>
        </div>
      </div>

      <div className="bg-teal text-paper rounded-2xl p-6 mb-8 flex items-center gap-4">
        <Users size={28} />
        <div>
          <p className="font-display text-4xl leading-none">{creator.contactCount || 0}</p>
          <p className="text-sm opacity-90">marca{(creator.contactCount || 0) !== 1 && "s"} te ha{(creator.contactCount || 0) !== 1 && "n"} contactado</p>
        </div>
      </div>

      {!editing ? (
        <div className="border border-line rounded-2xl p-5">
          <div className="flex justify-between items-center mb-3">
            <span className="font-mono text-xs uppercase tracking-wider text-ink/50">Tu ficha pública</span>
            <button onClick={() => { setForm(creator); setEditing(true); }} className="text-sm text-coral font-semibold">Editar</button>
          </div>
          <ul className="text-sm space-y-1.5 text-ink/75">
            <li>Edad: {creator.edad}</li>
            <li>Tarifa desde: ${creator.tarifaDesde} USD</li>
            <li>Categorías: {creator.categorias.join(", ")}</li>
            <li>Plataformas: {creator.plataformas.join(", ")}</li>
            <li>Portafolio: <a className="text-teal underline" href={creator.portafolioUrl} target="_blank" rel="noopener noreferrer">{creator.portafolioUrl}</a></li>
            <li>Contacto: {creator.contacto}</li>
          </ul>
        </div>
      ) : (
        <div className="border border-line rounded-2xl p-5">
          <Field label="Tarifa desde (USD)">
            <input type="number" className={inputCls} value={form.tarifaDesde} onChange={e => setForm({ ...form, tarifaDesde: e.target.value })} />
          </Field>
          <Field label="Link de portafolio">
            <input className={inputCls} value={form.portafolioUrl} onChange={e => setForm({ ...form, portafolioUrl: e.target.value })} />
          </Field>
          <Field label="Contacto">
            <input className={inputCls} value={form.contacto} onChange={e => setForm({ ...form, contacto: e.target.value })} />
          </Field>
          <Field label="Bio corta">
            <textarea maxLength={150} rows={3} className={inputCls} value={form.bio} onChange={e => setForm({ ...form, bio: e.target.value })} />
          </Field>
          <div className="flex gap-3">
            <button onClick={save} className="bg-ink text-paper px-5 py-2.5 rounded-full text-sm font-semibold">Guardar cambios</button>
            <button onClick={() => setEditing(false)} className="border border-line px-5 py-2.5 rounded-full text-sm">Cancelar</button>
          </div>
        </div>
      )}
    </main>
  );
}
